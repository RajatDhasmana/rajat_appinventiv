//
//  MultipleVC.swift
//  MultipleViews
//
//  Created by Mohd Sultan on 13/02/17.
//  Copyright © 2017 Appinventiv. All rights reserved.
//

import UIKit


class NameModel
{
    var name : String
    var color : UIColor
    init(dict data : [String:Any]) {
        name = data["name"] as! String
        color = data["color"] as! UIColor
    }
    
    
}



class MultipleVC: UIViewController {

  
    @IBOutlet weak var nameCollectionView: UICollectionView!
    
    
    
    @IBOutlet weak var switchButton: UIButton!
   
    
    var listflag = Bool()
    
    
    let names = [
        ["name" : "Rajat Dhasmana" , "color":UIColor.black],
        ["name" : "Rajat Dhasmana" , "color":UIColor.yellow],
        ["name" : "Rajat Dhasmana" , "color":UIColor.red],
        ["name" : "Rajat Dhasmana" , "color":UIColor.gray],
        ["name" : "Rajat Dhasmana" , "color":UIColor.blue],
        ["name" : "Rajat Dhasmana" , "color":UIColor.green],
        ["name" : "Rajat Dhasmana" , "color":UIColor.brown]
        
    ]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
  
    nameCollectionView.dataSource = self
        nameCollectionView.delegate = self
    
    
   
        let cellNib1 = UINib(nibName: "CollectionCell", bundle: nil)
        
         nameCollectionView.register(cellNib1, forCellWithReuseIdentifier: "CollectionCellID")
  
    
        let cellNib2 = UINib(nibName: "TableCell", bundle: nil)
        
        nameCollectionView.register(cellNib2, forCellWithReuseIdentifier: "TableCellID")
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


   
    @IBAction func pressedButton(_ sender: Any) {
    
 
    
    if switchButton.isSelected == true
    {   switchButton.isSelected = false
        listflag = false
                    }
    
    else
    {
        switchButton.isSelected = true
        listflag = true         }
    
    nameCollectionView.reloadData()
        
    }
    
    
}





extension MultipleVC : UICollectionViewDelegate , UICollectionViewDataSource , UICollectionViewDelegateFlowLayout
{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return names.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if listflag == false
        {    let collectioncell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCellID", for: indexPath) as! CollectionCell
        
        let nameobj = NameModel(dict : names[indexPath.item])
        
        collectioncell.configurecell(object: nameobj)
        
        return collectioncell
        }
        else
        {
        
            let tablecell = collectionView.dequeueReusableCell(withReuseIdentifier: "TableCellID", for: indexPath) as! TableCell
            
            let nameobj = NameModel(dict : names[indexPath.item])
            
            tablecell.configurecell(object: nameobj)
            
            return tablecell
        
        
        }
    }
   
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if listflag == true
        {
        
        return CGSize(width: 375, height: 73)
        }
    else
        {
            return CGSize(width: 160, height: 160)
        
        }
    
    }
    
}





















